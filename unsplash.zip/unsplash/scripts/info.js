
const config = require("scripts/config")
function resView(res) {
 $ui.toast("搜索成功")
 $ui.push({
 	props: {
        title: "搜索结果"
    },
    views:[
        {
		    type: "matrix", 
		    props: { 
			      id:"searchListView",
			      columns: 1, 
			      spacing: 10, 
			      selectable:true, 
			      waterfall:true, 
			      square:false,
			      bgcolor: $color("#eeeeee"),
			      template: [ 
			        { 
			          type: "image", 
			          props: {  
			            id:"searchRes",
			            smoothRadius:10

			          }, 
			          layout: $layout.fill
			        }
			      ] 
			    }, 
		    layout: (make,view)=> { 
		      make.top.equalTo(view.super)
		      make.centerX.equalTo(view.super)
		    }, 
		    events: { 
		      itemSize: (sender, indexPath) => {
		            return config.size[indexPath.item % 4]
		      },
		      didSelect: function(sender, indexPath, object) { 
		         $ui.push({ 
		           props: { 
		             title: "image" 
		           }, 
		           views: [{ 
		             type: "image", 
		             props: { 
		               id:"img",
		               src: object.image.src,
		               smoothRadius:10,
		             }, 
		             layout: (make,view)=>{
		               make.width.equalTo(wd-10)
		               make.height.equalTo(wh-150)
		               make.centerX.equalTo(view.super)
		             },
		             
		           },
		           {
		            type:"label",
		            props:{
		              text:"下载",
		              align: $align.center,
		              bgcolor:$color("#222"),
		              smoothRadius:10,
		              color:$color("#fff")

		            },
		            layout:(make,view)=>{
		                make.height.equalTo(50)
		                make.width.equalTo(wd-10)
		                make.centerX.equalTo(view.super)
		                make.bottom.equalTo(0
		                  )
		            },
		             events: { 
		               tapped: (sender)=> { 
		                 $http.download({ 
		                   url: object.image.src, 
		                   handler: function(resp) { 
		                     $share.universal(resp.data) 
		                     $app.tips("下载完成")
		                   } 
		                 }) 
		               } 
		             }
		           }
		           ] 
		         }) 
		      }, 
	          didReachBottom: (sender)=> { 
		        $ui.toast("请求数据中...") 
		        $device.taptic(1) 
		        page++; 
		        fetchData(page,'https://api.unsplash.com/search/photos?query='+searchTxt)
		        $delay(1.5, function() { 
		          sender.endFetchingMore() 
		        }) 
		      } 
		    } 
        }
    ],
    layout:(make,view)=>{
    	 make.bottom.top.right.left.equalTo(0)
    }
  })
   res.map((item)=> { 
       $("searchListView").data =item.results.map((i)=>{
       	console.log(i.cover_photo.urls.regular)
        return { searchRes: { src:i.cover_photo.urls.regular} } 
      })
    }) 
}

module.exports = {
    getView: resView
}